task :default do
	File.open("myproject.txt", 'a') do |f| 
		f.puts "Hello, #{FUBU_PROJECT_NAME}"
	end
end