task :default do
	File.open("MyProject.xml", 'w') {|f| f.write('Hello, World!') }
end